# Explicit disk remainder bounds — proposed technical supplement

**Release candidate v0.5; quantitative note v0.1a, 23 October 2026.**

Status: `RELEASE_CANDIDATE_DOI_RESERVED`. Reserved DOI for this version:
https://doi.org/10.5281/zenodo.23598602

Publication and a new tagged content commit are not yet attested.

Patrick Royer, independent researcher without institutional affiliation,
Dynagénèse project. Developed, counter-checked and integrated with
ChatGPT/Codex assistance. No independent human mathematical review or
formal proof verification is attested.

The nine-page note proposes explicit analytic constants
K_f=2.5e9, K_E=2000, K_geo=550000 and a common validity threshold R0=2
for the disk remainder in the two-term perimeter-deficit expansion.
The bound is deliberately conservative and uninformative at the radii
already computed. R0 is not a practical onset of the asymptotic regime.

Start with `DYN-CHIFFRAGE_RESTE_I43_DISQUE_v0_1a.pdf`, then the three
`*_constants.txt` derivations and `specialist_counterreview.txt`.
The starting proof under `source_math/` is preserved unchanged.

## Human review requested

Please read `REVIEW_REQUEST.en.md` or `REVIEW_REQUEST.fr.md`.
We seek localized mathematical objections and corrections, especially on
the geometric identities, the quantitative Stieltjes/heat chain and possible
observable-specific improvements. Feedback may be posted in the public
[repository Issues](https://github.com/royerpatrick-ops/dyn-validex-cinf-deficit-perimetre/issues).
No independent human reviewer or endorsement is claimed.

## Reproduce the arithmetic and figure

Python 3, NumPy and Matplotlib are required. From this directory:

```sh
python3 evaluate_explicit_budget.py results_reproduced
```

The script uses exact rational arithmetic for the integer upper bounds and
the sufficient remote threshold. Floating point serves only indicative
decimal displays and figures. It performs no sampling, fit, or execution
of code from an input archive. These arithmetic checks do not formalize
the mathematical proof.

Compile the note with XeLaTeX, Latin Modern Roman and DejaVu fonts, keeping
`portee_majorant.pdf` beside the source:

```sh
xelatex -interaction=nonstopmode -halt-on-error DYN-CHIFFRAGE_RESTE_I43_DISQUE_v0_1a.tex
```

## Français

Ce complément expose des majorants analytiques proposés et un appel à
relecture humaine. La version documentaire v0.1a précise que la moyenne
entièrement certifiée à R=50 reste un objectif éventuel : C51 est partiel.
Les constantes et les calculs de la note interne v0.1 sont inchangés.
Voir `LISEZMOI.txt`, la note et les dérivations pour les domaines exacts.

Les outils utilisés sont Python, NumPy, Matplotlib, XeLaTeX et Poppler.
Leurs composants et les textes tiers gardent leurs propres licences.
Le dossier n'inclut pas leur code.

## History and licence

This is a supplement to the v0.4 proposed proof, DOI
https://doi.org/10.5281/zenodo.23258648, in the series with concept DOI
https://doi.org/10.5281/zenodo.23209552.

The custom DEL1.1 operative text is supplied unchanged in
`DYN-LICENCE_DEL_v1_1.pdf`; see `LICENSE_SCOPE.txt` for the designated scope.
DEL1.1 is not OSI-approved. No CC/MIT substitution or exclusive rights over
mathematical facts are claimed. Earlier versions retain their own notices.

See `RELEASE_NOTES_v0_5.md`, `PROVENANCE_PUBLICATION.json`,
`CITATION.cff`, `ZENODO_METADATA.json` and `MANIFEST_SHA256.txt` for version and file provenance.
