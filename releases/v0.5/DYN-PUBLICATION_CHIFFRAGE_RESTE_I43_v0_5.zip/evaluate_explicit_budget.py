"""Evaluate the proposed analytic bound; no sampling or fit.

The integer upper bounds and the remote threshold use Fraction arithmetic.
Floating point is used only for a figure and indicative decimal displays.
Usage: python3 evaluate_explicit_budget.py OUTPUT_DIRECTORY
Requires matplotlib and numpy for the figure; the arithmetic is standard Python.
"""
from fractions import Fraction as Q
from pathlib import Path
import csv
import json
import math
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

KF = 2_500_000_000
KE = 2_000
KG = 550_000
R0 = 2
BITS = 128


def log_interval_unit(x, terms=64):
    """Rational enclosure of log(x), 1 <= x <= 2, by atanh series."""
    assert Q(1) <= x <= Q(2)
    u = (x - 1) / (x + 1)
    total = sum((2 * u**(2*j+1) / (2*j+1) for j in range(terms)), Q(0))
    tail = 2 * u**(2*terms+1) / ((2*terms+1) * (1-u*u))
    return total, total+tail


def log_upper_integer(r):
    k = r.bit_length()-1
    _, upper2 = log_interval_unit(Q(2))
    _, upper_y = log_interval_unit(Q(r, 2**k))
    return k*upper2+upper_y


def inverse_power_upper(r, a, b):
    """Dyadic enclosure of r**(-a/b), justified by exact integer comparisons."""
    scale = 2**BITS
    target = scale**b
    multiplier = r**a
    low, high = 0, scale+1
    while high-low > 1:
        mid = (low+high)//2
        if mid**b * multiplier <= target:
            low = mid
        else:
            high = mid
    lower = Q(low, scale)
    upper = lower if low**b*multiplier == target else Q(low+1, scale)
    assert lower**b*multiplier <= 1 <= upper**b*multiplier
    return lower, upper


def exact_budget_upper(r):
    assert isinstance(r, int) and r >= R0
    lu = log_upper_integer(r)
    pu = [inverse_power_upper(r, a, b)[1] for a,b in ((11,21),(7,12),(4,3))]
    components = [Q(44,7)*KF*(1+lu/3)*pu[0], Q(44,7)*KE*pu[1], KG*pu[2]]
    return sum(components, Q(0)), components


def ceil_rational(q):
    return -(-q.numerator//q.denominator)


def fraction_data(q):
    return {'numerator':str(q.numerator),'denominator':str(q.denominator)}


out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)
rows, certificates = [], []
for r in (2,25,50,100,200,400,800,1600,100_000):
    upper, components = exact_budget_upper(r)
    numeric = 2*math.pi*(KF*(1+math.log(r)/3)*r**(-11/21)+KE*r**(-7/12))+KG*r**(-4/3)
    row = {'R':r,'analytic_budget_decimal_indicative':numeric,
           'integer_upper_bound_exact_arithmetic':ceil_rational(upper),
           'spectral_part_indicative':float(components[0]),
           'singular_part_indicative':float(components[1]),
           'geometric_part_indicative':float(components[2])}
    rows.append(row)
    certificates.append({'R':r,'rational_upper':fraction_data(upper),
                         'integer_upper_bound':ceil_rational(upper)})

# For R=2^(84k), log(R)/3 <20k since log(2)<7/10, and 2*pi<7.
# For R>=2^84, (1+log(R)/3)R^(-1/42) is decreasing: log(R)>39.
def normalized_grid_upper(k):
    return Q(7*KF*(1+20*k),2**(2*k))+Q(7*KE,2**(7*k))+Q(KG,2**(70*k))

k = 1
while normalized_grid_upper(k) > Q(1,100):
    k += 1
grid_upper = normalized_grid_upper(k)
ln2lo, ln2hi = log_interval_unit(Q(2))
assert ln2lo > Q(1,2) and ln2hi < Q(7,10)
assert grid_upper <= Q(1,100)
assert k == 1 or normalized_grid_upper(k-1) > Q(1,100)

# Exact arithmetic checks used in the deductions, distinct from any proof check.
arithmetic = {
    'W1_norm_squared_below_120001_squared':32**2+3*65000**2 <120001**2,
    'Kf_rounded_up':10*120000+20000*120001 <=KF,
    'Kgeo_with_pi_upper':Q(4,3)*Q(22,7)*130077 <KG,
    'gamma_lower_above_one_quarter':Q(8,27) >Q(1,4),
    'heat_trace_with_e_upper':Q(1280*3**6,12) <100000,
    'exp_5_over_4_lower_above_10_over_3':sum((Q(5,4)**j/math.factorial(j) for j in range(4)),Q(0)) >Q(10,3),
    'mellin_rounded_up':1935+18 <KE,
    'all_budget_integer_ceilings_checked':all(Q(c['integer_upper_bound']) >= Q(int(c['rational_upper']['numerator']),int(c['rational_upper']['denominator'])) for c in certificates)
}
assert all(arithmetic.values())

with (out/'budget_explicit.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]))
    writer.writeheader();writer.writerows(rows)
result={'constants':{'K_f':KF,'K_E':KE,'K_geo':KG,'R0':R0},
        'scope':'Arithmetic checks of the proposed analytic bound; not a formal verification of the mathematical proof.',
        'cutoff':'eta=1/2; chi=1 up to rho=1/2; 1-10u^3+15u^4-6u^5, u=2rho-1, to rho=1; zero afterwards; C2.',
        'metric':'X0,Y0,Theta orthonormal; left invariant; Haar probability.',
        'rounding_method':'Fraction arithmetic, 128-bit dyadic inverse powers, 64-term atanh log enclosure, pi<22/7.',
        'budget_integer_certificates':certificates,'arithmetic_checks':arithmetic,
        'remote_threshold':{'target':'|r(R)| <= (1/100) R^(-1/2)',
                            'k':k,'R_expression':f'2^{84*k}',
                            'log10_R_indicative':84*k*math.log10(2),
                            'normalized_upper_rational':fraction_data(grid_upper),
                            'normalized_upper_decimal_indicative':float(grid_upper),
                            'valid_for_all_R_above_threshold':True,
                            'optimal_threshold_claimed':False}}
(out/'budget_arithmetic_controls.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,
                     'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
fig,axes=plt.subplots(1,2,figsize=(8.5,3.3),layout='constrained')

def log_normalized_budget(x):
    spectral = math.log10(2*math.pi*KF)+np.log10(1+x*math.log(10)/3)-x/42
    singular = math.log10(2*math.pi*KE)-x/12
    geometry = math.log10(KG)-5*x/6
    maxlog=np.maximum.reduce([spectral,singular,geometry])
    return maxlog+np.log10(10**(spectral-maxlog)+10**(singular-maxlog)+10**(geometry-maxlog))

for ax,limits in zip(axes,[(math.log10(2),5),(math.log10(2),650)]):
    x=np.linspace(*limits,700)
    ax.plot(x,log_normalized_budget(x),color='#176f9d',lw=2)
    ax.set_xlim(*limits)
    ax.set_xlabel(r'$\log_{10} R$')
    ax.grid(color='#e2e7eb',lw=.6)
axes[0].set_title('Rayons accessibles : borne très large',loc='left',fontweight='bold')
axes[0].set_ylabel(r'$\log_{10}(\sqrt{R}\,\mathcal{B}(R))$')
for r in (50,1600):
    x=math.log10(r);y=float(log_normalized_budget(np.array(x)))
    axes[0].scatter([x],[y],color='#176f9d',s=20)
    axes[0].annotate(f'R={r}',(x,y),xytext=(0,-17),textcoords='offset points',ha='center',fontsize=8)
axes[1].set_title('Décroissance asymptotique lente',loc='left',fontweight='bold')
axes[1].axhline(-2,color='#bd6632',lw=1.2,ls='--',label=r'$\mathcal{B}(R)\leq 0{,}01 R^{-1/2}$')
axes[1].axvline(84*k*math.log10(2),color='#303a46',lw=1,ls=':')
axes[1].annotate(r'$R=2^{2100}$',(84*k*math.log10(2),-2),xytext=(-8,12),textcoords='offset points',ha='right',fontsize=9)
axes[1].set_ylim(-3,12)
axes[1].legend(loc='upper right',frameon=False,fontsize=8)
fig.savefig(out/'portee_majorant.pdf',bbox_inches='tight')
fig.savefig(out/'portee_majorant.png',dpi=240,bbox_inches='tight')
plt.close(fig)

print(json.dumps({'constants':result['constants'],'rows':rows,
                  'arithmetic_checks':arithmetic,
                  'remote_threshold':{key:val for key,val in result['remote_threshold'].items() if key!='normalized_upper_rational'}},ensure_ascii=False,indent=2))
