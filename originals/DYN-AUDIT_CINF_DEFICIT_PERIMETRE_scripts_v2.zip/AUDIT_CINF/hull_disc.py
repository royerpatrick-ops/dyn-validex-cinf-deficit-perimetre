"""Simulation indépendante : déficit de périmètre de conv(L ∩ R·D), L = rotation(θ)·Z² + translation uniforme.
C_eff = E[2πR − P_hull]·R^{1/3}/(2π)."""
import numpy as np, sys, math
def hull_perimeter(px, py):
    o = np.lexsort((py, px)); P = np.column_stack((px[o], py[o]))
    def chain(pts):
        h = []
        for p in pts:
            while len(h) >= 2 and (h[-1][0]-h[-2][0])*(p[1]-h[-2][1]) - (h[-1][1]-h[-2][1])*(p[0]-h[-2][0]) <= 0:
                h.pop()
            h.append(tuple(p))
        return h
    lo = chain(P); up = chain(P[::-1]); H = np.array(lo[:-1] + up[:-1])
    return np.sum(np.hypot(*(np.roll(H, -1, 0) - H).T))
def one(R, rng):
    th = rng.uniform(0, np.pi/2); u, v = rng.random(2)
    c, s = math.cos(th), math.sin(th)
    # point du réseau : p = rot(θ)·(m+u, n+v). On balaie m ; pour chaque m, les n admissibles forment un intervalle.
    M = int(math.ceil(R)) + 2
    m = np.arange(-M, M+1) + u
    # |rot·(m, y)|² = m² + y² ≤ R²  (rotation isométrique) → y ∈ [-√(R²-m²), √(R²-m²)], y = n+v
    rad2 = R*R - m*m; ok = rad2 >= 0; m = m[ok]; r = np.sqrt(rad2[ok])
    nlo = np.ceil(-r - v); nhi = np.floor(r - v); ok = nlo <= nhi
    m, nlo, nhi = m[ok], nlo[ok] + v, nhi[ok] + v
    X = np.concatenate([m, m]); Y = np.concatenate([nlo, nhi])
    px, py = c*X - s*Y, s*X + c*Y
    return 2*np.pi*R - hull_perimeter(px, py)
if __name__ == "__main__":
    rng = np.random.default_rng(42)
    for R, n in ((1230.0, 400), (9587.0, 300), (110000.0, 120)):
        vals = np.array([one(R, rng) for _ in range(n)])*R**(1/3)/(2*np.pi)
        print(f"R={R:9.0f}  C_eff = {vals.mean():.5f} ± {vals.std(ddof=1)/np.sqrt(n):.5f}  (n={n})", flush=True)
    print("dépôt : R=1230 → 0,62927 ± 0,00253 ; R=9587 → 0,65808 ± 0,00207 ; R=110000 → 0,67935 ± 0,00073")
