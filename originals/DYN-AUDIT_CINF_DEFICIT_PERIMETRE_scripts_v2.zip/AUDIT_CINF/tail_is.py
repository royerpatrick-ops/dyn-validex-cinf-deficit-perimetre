"""Queue de J par échantillonnage préférentiel : β = b mod a, b tiré d'un mélange uniforme + Cauchy centré en 0."""
import numpy as np, json, sys
def G_is(a, n, seed, p_unif=0.25, sig_fac=4.0):
    rng = np.random.default_rng(seed)
    sig = sig_fac/a**2; half = a/2
    Zc = (2/np.pi)*np.arctan(half/sig)
    unif = rng.random(n) < p_unif
    b = np.empty(n)
    b[unif] = rng.uniform(-half, half, unif.sum())
    m = (~unif).sum(); out = np.empty(0)
    while out.size < m:   # Cauchy tronquée à [-a/2, a/2]
        c = sig*np.tan(np.pi*(rng.random(2*m) - 0.5)); out = np.concatenate([out, c[np.abs(c) <= half]])
    b[~unif] = out[:m]
    q = p_unif/a + (1 - p_unif)/(np.pi*sig*(1 + (b/sig)**2))/Zc
    w = (1/a)/q
    be = np.mod(b, a)
    de = rng.uniform(0, 1/a, n); s = rng.uniform(0, a, n)
    cc = np.zeros(n); idx = np.arange(n); k = 0
    while idx.size:
        d = de[idx] + k/a; L = np.sqrt(2*d); off = s[idx] + k*be[idx]
        x1 = off + a*np.ceil((-L - off)/a); x2 = off + a*np.floor((L - off)/a)
        occ = x1 <= x2 + 1e-12
        cc[idx[occ]] = (d*(x2 - x1) - (x2**3 - x1**3)/3)[occ]
        idx = idx[~occ]; k += 1
    v = cc*w
    return v.mean(), v.std(ddof=1)/np.sqrt(n), k
if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "check":
        for a in (3.0, 5.0):
            m, se, k = G_is(a, 2_000_000, 7)
            print(f"IS  a={a}: a·G={a*m:.5e} ± {a*se:.1e}")
    else:
        grid = np.exp(np.linspace(np.log(3.6), np.log(48), 22))
        rows = []
        for i, a in enumerate(grid):
            n = 1_000_000 if a < 12 else (400_000 if a < 25 else 200_000)
            m, se, k = G_is(a, n, 500 + i)
            rows.append((float(a), float(a*m), float(a*se), int(k)))
            print(f"a={a:7.3f}  a·G={a*m:.5e} ± {a*se:.1e}  rel={se/m if m else 0:.3f}  a²·(a·G)={a**3*m:.4f}  rangs≤{k}", flush=True)
        json.dump(rows, open(mode, "w"))
