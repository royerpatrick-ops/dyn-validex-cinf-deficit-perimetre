"""Test du cadre (densité 6/π² + loi idéale) sur le nombre de sommets : prédiction E V / R^{2/3} = (12/π)·J_V,
J_V = ∫_0^∞ a·p(a) da, p(a) = P(la première rangée occupée contient ≥ 2 points). Cible : Balog–Deshouillers 3,4536898915…"""
import numpy as np, mpmath as mp
mp.mp.dps = 25
def P2(r, a):   # P(≥2 points dans une fenêtre fermée de demi-largeur r, phase uniforme)
    x = 2*r/a - 1
    return mp.mpf(0) if x <= 0 else (mp.mpf(1) if x >= 1 else x)
def p_exact(a):  # 0 < a ≤ 2 : rangs 0 ou 1
    a = mp.mpf(a); h = a**2/8
    f = lambda d: P2(mp.sqrt(2*d), a) + (1 - min(mp.mpf(1), 2*mp.sqrt(2*d)/a))*P2(mp.sqrt(2*(d + 1/a)), a)
    pts = sorted({mp.mpf(0), min(h, 1/a), 1/a} | {x for x in (a**2/2, a**2/2 - 1/a, a**2/8 - 1/a) if 0 < x < 1/a})
    return a*mp.quad(f, pts)
def p_mc(a, n, seed):
    rng = np.random.default_rng(seed)
    de = rng.uniform(0, 1/a, n); s = rng.uniform(0, a, n); be = rng.uniform(0, a, n)
    two = np.zeros(n); idx = np.arange(n); k = 0
    while idx.size:
        d = de[idx] + k/a; L = np.sqrt(2*d); off = s[idx] + k*be[idx]
        x1 = off + a*np.ceil((-L - off)/a); x2 = off + a*np.floor((L - off)/a)
        occ = x1 <= x2 + 1e-12
        two[idx[occ]] = (x2 - x1 > a/2)[occ]
        idx = idx[~occ]; k += 1
    return two.mean(), two.std(ddof=1)/np.sqrt(n)
if __name__ == "__main__":
    for a in (0.5, 1.3, 2.0):
        m, se = p_mc(a, 2_000_000, 11)
        print(f"a={a}: p exact={float(p_exact(a)):.6f}  MC={m:.6f}±{se:.6f}")
    JV02 = mp.quad(lambda a: a*p_exact(a), [0, 0.5, 1, mp.cbrt(2), mp.mpf(1.5), 2])
    grid = np.linspace(2, 4, 21); vals = []
    for i, a in enumerate(grid):
        m, se = p_mc(a, 2_000_000, 50 + i); vals.append(a*m)
    from scipy.integrate import simpson
    JVt = simpson(vals, x=grid)
    print("a·p(a) à a = 2, 3, 4 :", vals[0], vals[10], vals[-1])
    JV = float(JV02) + JVt
    print(f"J_V(0,2] = {float(JV02):.8f} ; queue [2,4] = {JVt:.6f} ; J_V = {JV:.6f}")
    tail = (8/3)/(4*4**4)   # queue a > 4 : a·p(a) ~ 8/(3a^5)
    print(f"Sans la queue a > 4 : (12/π)·J_V = {12/np.pi*JV:.5f}")
    print(f"Avec la queue 8/(3a⁵) : (12/π)·J_V = {12/np.pi*(JV + tail):.5f}   | Balog–Deshouillers : 3.4536898915")
