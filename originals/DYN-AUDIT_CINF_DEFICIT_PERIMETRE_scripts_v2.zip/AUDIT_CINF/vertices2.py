"""Affinage du test sommets : [2,4] avec 8·10⁶ tirages par point, contrôle de l'asymptote a·p(a) ~ 8/(3a⁵) à a = 5, 6, 7."""
import numpy as np, sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from vertices import p_mc
from scipy.integrate import simpson
grid = np.linspace(2, 4, 21); vals, ses = [], []
for i, a in enumerate(grid):
    m1, s1 = p_mc(a, 4_000_000, 900 + i); m2, s2 = p_mc(a, 4_000_000, 1900 + i)
    m = (m1 + m2)/2; se = np.hypot(s1, s2)/2
    vals.append(a*m); ses.append(a*se)
w = np.full(len(grid), 2.0); w[1:-1:2] = 4; w[0] = w[-1] = 1; w *= (grid[1]-grid[0])/3
J24 = simpson(vals, x=grid); J24_se = np.sqrt(np.sum((w*np.array(ses))**2))
for a in (5.0, 6.0, 7.0):
    m, se = p_mc(a, 8_000_000, int(a*100))
    print(f"a={a}: a·p(a) = {a*m:.3e} ± {a*se:.1e}   asymptote 8/(3a⁵) = {8/(3*a**5):.3e}")
J02 = 0.86125501   # partie exacte (vertices.py)
tail = (8/3)/(4*4**4)
JV = J02 + J24 + tail
print(f"[2,4] = {J24:.6f} ± {J24_se:.6f} ; queue [4,∞) = {tail:.6f} ; J_V = {JV:.6f}")
print(f"(12/π)·J_V = {12/np.pi*JV:.5f} ± {12/np.pi*J24_se:.5f}   | Balog–Deshouillers : 3.45369 (3.4536898915)")
