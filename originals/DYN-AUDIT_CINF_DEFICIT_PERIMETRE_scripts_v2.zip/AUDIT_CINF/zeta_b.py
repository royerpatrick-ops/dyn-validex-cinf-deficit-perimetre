"""Ordre principal du second terme par coupure entière de la queue a·G ~ 1/(9a²) :
B_coupure = -(c0/π)·Z_prim(3/4), c0 = √2/30, Z_prim(s) = 4ζ(s)β(s)/ζ(2s). Résultat ≈ 0,058 (≠ B ajusté ≈ 0,29-0,30)."""
import mpmath as mp
mp.mp.dps = 30
inner = lambda m: mp.quad(lambda B: B**-0.5*min(2*m, 1 - B), [0, max(mp.mpf(0), 1 - 2*m), 1])
c0 = mp.sqrt(2)/24*2*mp.quad(inner, [0, 0.5])
Zp = 4*mp.zeta(0.75)*mp.dirichlet(0.75, [0, 1, 0, -1])/mp.zeta(1.5)
print("c0 =", c0, " (√2/30 =", mp.sqrt(2)/30, ")")
print("Z_prim(3/4) =", Zp, " ; B_coupure =", -c0/mp.pi*Zp)
