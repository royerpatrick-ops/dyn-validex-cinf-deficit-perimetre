Prédiction de la constante C∞ du déficit de périmètre de l'enveloppe entière randomisée par le modèle idéal
Audit du 6 octobre 2026 — dépôts Zenodo 23110956 (déficit-périmètre v0.1a) et 23188815 (pont idéal [1,2])
Dépendances : numpy scipy mpmath pandas

cinf.py      G(a) exact sur ]0,2] (formule du pont, contrôlée par Monte-Carlo à a = 0,3 ; 0,7 ; 1,5 ; 2),
             J sur ]0,2] = 1,10716 ; queue [2 ; 3,6] par Monte-Carlo.                         (≈ 1 min)
tail_is.py   Queue a > 3,6 par échantillonnage préférentiel (β ≈ 0 mod a) : a·G ≈ 1/(9a²).
             Usage : python tail_is.py check | python tail_is.py tail_is.json                   (≈ 6 min)
zeta_b.py    Ordre principal du second terme par coupure entière : B ≈ 0,058 (insuffisant).
fit_gamma.py Ajustements sur les moyennes du dépôt : python fit_gamma.py reanalysis_92_points.csv
hull_disc.py Simulation indépendante d'enveloppes entières randomisées du disque (R = 1230 ; 9587 ; 110000). (≈ 5 min)

Résultat : C∞(théorie) = (6/π²)·∫_0^∞ a·G(a) da ≈ 0,7193 (0,7188–0,7195 selon le modèle de queue),
contre 0,7198 ± 0,0014 (ajustement libre, 69 points) et 0,7192 (valeur fixée du dépôt).
Dérivation heuristique (Cauchy + décomposition exacte par arêtes + densité 6/π² + équidistribution) : non démontrée.

Ajout du 6 octobre (vérification bibliographique) :
vertices.py   Même cadre appliqué au nombre de sommets : p(a) exact sur ]0,2], Monte-Carlo sur [2,4],
              queue a·p(a) ~ 8/(3a⁵). Usage : python vertices.py                                  (≈ 40 s)
vertices2.py  Affinage ([2,4] à 8·10⁶ tirages par point, asymptote contrôlée à a = 5, 6, 7).
              Résultat (12/π)·J_V = 3,45360 ± 0,00014, contre 3,4536898915 (Balog–Deshouillers 1999). (≈ 35 s)
