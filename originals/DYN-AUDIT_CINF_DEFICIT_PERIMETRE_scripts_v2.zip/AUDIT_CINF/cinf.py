"""Prédiction de C_inf par le modèle idéal : C_inf =? (6/π²)·J, J = ∫_0^∞ a·G(a) da.
G(a) exact (formule du pont) pour 0 < a ≤ 2 ; Monte-Carlo du modèle pour a > 2 et contrôle MC pour a < 1."""
import numpy as np, mpmath as mp, sys
mp.mp.dps = 20

def Hm(d, a):
    r = mp.sqrt(2*d)
    return mp.mpf(0) if r < a/2 else (2*r - a)*(r**2 + 2*a*r - a**2)/6
def G_exact(a):  # valable pour 0 < a <= 2 (rang 0 ou 1, h = a²/8 < 1/a)
    a = mp.mpf(a); h = a**2/8
    g0 = a*mp.quad(lambda d: Hm(d, a), [h, 1/a])
    g1 = a*mp.quad(lambda d: (1 - 2*mp.sqrt(2*d)/a)*Hm(d + 1/a, a), [0, h])
    return g0 + g1

def G_mc(a, n=2_000_000, seed=1):
    rng = np.random.default_rng(seed)
    de = rng.uniform(0, 1/a, n); s = rng.uniform(0, a, n); be = rng.uniform(0, a, n)
    cc = np.zeros(n); done = np.zeros(n, bool); k = 0
    while not done.all():
        d = de + k/a; L = np.sqrt(2*d); off = s + k*be
        x1 = off + a*np.ceil((-L - off)/a); x2 = off + a*np.floor((L - off)/a)
        occ = (x1 <= x2 + 1e-12) & ~done
        cc[occ] = (d*(x2 - x1) - (x2**3 - x1**3)/3)[occ]
        done |= occ; k += 1
    return cc.mean(), cc.std(ddof=1)/np.sqrt(n), k

# 1. contrôle de la formule exacte hors de [1,2]
for a in (0.3, 0.7, 1.5, 2.0):
    m, se, k = G_mc(a)
    print(f"a={a}: G exact={float(G_exact(a)):.6f}  MC={m:.6f}±{se:.6f}  (rangs parcourus ≤ {k})")

# 2. J sur ]0,2] : a = u², da = 2u du (intégrande bornée)
J02 = mp.quad(lambda u: 2*u**3*G_exact(u**2), [0, mp.mpf('0.5'), 1, mp.sqrt(mp.cbrt(2)), mp.sqrt(2)])
J12 = mp.quad(lambda a: a*G_exact(a), [1, mp.cbrt(2), mp.cbrt(mp.mpf(8)/3), 2])
print(f"J sur [1,2] = {mp.nstr(J12, 12)}  (pont déposé : 0,2346892660…)")
print(f"J sur ]0,2] = {mp.nstr(J02, 12)}")

# 3. queue a > 2 par Monte-Carlo sur une grille, Simpson
grid = np.linspace(2, 3.6, 17)
vals, ses = [], []
for i, a in enumerate(grid):
    m, se, k = G_mc(a, n=4_000_000, seed=100 + i)
    vals.append(a*m); ses.append(a*se)
    print(f"  a={a:.2f}  a·G={a*m:.3e} ± {a*se:.1e}  (rangs ≤ {k})")
from scipy.integrate import simpson
Jtail = simpson(vals, x=grid)
Jtail_se = np.sqrt(np.sum((np.array(ses)*(grid[1]-grid[0]))**2))
J = float(J02) + Jtail
C = 6/np.pi**2*J
print(f"queue [2,3.6] = {Jtail:.6f} ± {Jtail_se:.6f}")
print(f"J total ≈ {J:.6f} ;  (6/π²)·J = {C:.5f} ± {6/np.pi**2*Jtail_se:.5f}")
print("dépôt : C_inf libre = 0,72041 ± 0,00055 ; C_inf fixé = 0,7192")
