"""Ajustements sur les moyennes du dépôt (fichier reanalysis_92_points.csv du paquet de contre-vérification) :
C∞ fixé à la valeur théorique 0,7193, puis tout libre."""
import sys, pandas as pd, numpy as np
from scipy.optimize import curve_fit
d = pd.read_csv(sys.argv[1]); Cth = 0.7193
for label, sel in [("disque", (d.forme=='ellipse')&(d.param==1.0)), ("noyau 69 pts", d.forme=='ellipse')]:
    g = d[sel]; x, y, se, r = g.R.values, g.C_eff.values, g.C_eff_se.values, g.ratio_I32_I43.values
    (A, gam), cov = curve_fit(lambda X, A, gm: Cth - A*r*X**(-gm), x, y, p0=[.3, 1/6], sigma=se, absolute_sigma=True)
    (C, A2, g2), cov2 = curve_fit(lambda X, C, A, gm: C - A*r*X**(-gm), x, y, p0=[.72, .3, 1/6], sigma=se, absolute_sigma=True, maxfev=20000)
    print(f"{label}: C∞ fixé → γ={gam:.4f}±{np.sqrt(cov[1,1]):.4f}, B={A:.4f}±{np.sqrt(cov[0,0]):.4f} | libre → C∞={C:.4f}±{np.sqrt(cov2[0,0]):.4f}, γ={g2:.3f}±{np.sqrt(cov2[2,2]):.3f}")
